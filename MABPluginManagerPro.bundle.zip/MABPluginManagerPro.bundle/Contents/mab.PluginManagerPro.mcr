macroScript PluginManagerPro category:"MYARTSBOX" tooltip:"Plugin Manager Pro"
(
    filein "mab.PluginManagerPro.ms" 
)